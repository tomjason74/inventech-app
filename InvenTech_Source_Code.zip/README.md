# InvenTech IT Asset Management System (Prototype)

InvenTech is a modern, prototype IT Asset Management (ITAM) application designed to simulate enterprise-grade asset lifecycle management. It showcases data integrity controls, automated workflows, predictive diagnostics, change data capture (CDC), and cryptographic audit logging.

---

## 🚀 Key Features & Simulations

### 1. Relational Database Simulator (PostgreSQL)
- Supports registration, lookup, and updates of physical assets.
- Enforces relational constraints (such as preventing asset creation with duplicate serial numbers or asset tags).

### 2. Document Store Simulator (MongoDB)
- Manages unstructured/semi-structured maintenance tickets, tracking technician notes, issue types, and resolution states.

### 3. Change Data Capture & Messaging (Debezium + Kafka)
- Simulates real-time HRIS status synchronization (e.g., when a user is marked "Inactive" or "Terminated").
- Triggers Kafka message streams to automatically reclaim software licenses and unassign physical devices, moving them back to inventory with a pending sanitization status.

### 4. Stateful Orchestration Workflows (Temporal)
- Manages the procurement process (Manager Approval -> Ordered -> Received -> Registered).
- Simulates automated back-end job queuing and Snipe-IT inventory sync.

### 5. AI Diagnostics & Analytics (AWS SageMaker)
- Telemetry batch inference simulation that analyzes battery health, temperature, and storage metrics to predict imminent hardware failures and automatically open preventive maintenance logs.

### 6. Sanitization & Cryptographic Signatures
- Enforces NIST 800-88 sanitization standards before asset retirement or disposal.
- Cryptographically signs check-out actions and final disposal certificates, storing tamper-evident hashes.

---

## 🛠️ Tech Stack

- **Frontend**: Vanilla HTML5, CSS3 (Modern dark-mode glassmorphic theme), JavaScript (ES6 Modules & Fetch API).
- **Backend**: Node.js, Express.js.
- **Database**: File-based database simulation (`data/db.json` / `data/db.seed.json`).

---

## 📂 Project Structure

```
asdi-nila-mich-joy-jolyn/
├── data/
│   ├── db.json             # Live database state (simulated)
│   └── db.seed.json        # Original seed state for resets
├── public/
│   ├── css/
│   │   └── style.css       # Premium responsive stylesheet
│   ├── js/
│   │   └── app.js          # Main frontend control logic
│   ├── favicon.svg         # InvenTech Favicon
│   └── index.html          # Core single-page interface
├── server.js               # Node/Express server and API simulators
├── package.json            # Node.js dependencies and run scripts
├── README.md               # Project documentation
└── DEPLOYMENT_GUIDE.md     # Step-by-step GitHub & Hosting deploy instructions
```

---

## ⚙️ Local Setup and Installation

### Prerequisites
- [Node.js](https://nodejs.org/) (Version v18.0.0 or higher recommended)
- npm (Node Package Manager)

### Step 1: Install Dependencies
Navigate to the root directory of the application and install the required Express package:
```bash
npm install
```

### Step 2: Run the Server
You can start the server in development mode using:
```bash
npm run dev
```
Alternatively, start it via node:
```bash
npm start
```

### Step 3: Access the App
Open your web browser and navigate to:
```
http://localhost:3000
```

---

## 📜 API Documentation Summary

| Endpoint | Method | Description |
|---|---|---|
| `/api/data` | GET | Retrieve full system state |
| `/api/assets` | GET / POST | Fetch assets / Register a new physical asset |
| `/api/assets/:id/checkout` | POST | Check out an asset with a digital signature |
| `/api/assets/:id/checkin` | POST | Check in an asset and set sanitization status to pending |
| `/api/assets/:id/retire` | POST | Retire an asset (triggers sanitization check) |
| `/api/assets/:id/dispose` | POST | Finalize disposal and generate cryptographic audit certificate |
| `/api/maintenance` | POST | Open new maintenance logs |
| `/api/maintenance/:id/resolve`| POST | Resolve open maintenance logs |
| `/api/workflows` | POST | Trigger Temporal procurement approvals |
| `/api/workflows/:id/approve` | POST | Approve procurement workflow (starts Snipe-IT auto-intake) |
| `/api/simulation/hris-sync` | POST | Simulate user departure CDC & license/asset auto-reclamation |
| `/api/simulation/predictive-maintenance` | POST | Run SageMaker ML diagnostic batch inference |
| `/api/reset` | POST | Reset simulated database back to initial seed data |

---

## 📝 License
This project was developed as part of academic work. All rights reserved.
